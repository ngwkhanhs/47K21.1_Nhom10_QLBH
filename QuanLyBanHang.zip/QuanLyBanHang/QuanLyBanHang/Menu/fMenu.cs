﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace QuanLyBanHang
{
    public partial class fMenu : Form
    {
        public fMenu()
        {
            InitializeComponent();
        }

        private void fMenu_Load(object sender, EventArgs e)
        {
            dgv_Menu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Menu.DataSource = getMenu().Tables[0];
        }

        DataSet getMenu()
        {
            
            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM MON";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                //
                connection.Close();
            }

            return data;

        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }



        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private bool KiemTra()
        {
            if (txt_MaMon.Text == "" & txt_TenMon.Text == "" & txt_Gia.Text == "")
            {
                return false;
            }
            return true;
        }

        private void Reset()
        {
            txt_MaMon.Text = "";
            txt_TenMon.Text = "";
            txt_Gia.Text = "";
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "ThemMenu";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@MaMon", SqlDbType.NVarChar).Value = txt_MaMon.Text;
                        cmd.Parameters.Add("@TenMon", SqlDbType.NVarChar).Value = txt_TenMon.Text;
                        cmd.Parameters.Add("@DonGia", SqlDbType.NVarChar).Value = txt_Gia.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fMenu_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "SuaMenu";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@MaMon", SqlDbType.NVarChar).Value = txt_MaMon.Text;
                        cmd.Parameters.Add("@TenMon", SqlDbType.NVarChar).Value = txt_TenMon.Text;
                        cmd.Parameters.Add("@DonGia", SqlDbType.NVarChar).Value = txt_Gia.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fMenu_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã sửa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "XoaMenu";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@MaMon", SqlDbType.NVarChar).Value = txt_MaMon.Text;
                        cmd.Parameters.Add("@TenMon", SqlDbType.NVarChar).Value = txt_TenMon.Text;
                        cmd.Parameters.Add("@DonGia", SqlDbType.NVarChar).Value = txt_Gia.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fMenu_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }
    }

}
