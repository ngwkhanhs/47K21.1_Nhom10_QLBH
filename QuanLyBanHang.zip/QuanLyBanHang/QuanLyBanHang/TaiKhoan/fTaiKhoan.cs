﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fTaiKhoan : Form
    {
        public fTaiKhoan()
        {
            InitializeComponent();
        }

        private void fTaiKhoan_Load(object sender, EventArgs e)
        {
            dgv_TaiKhoan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_TaiKhoan.DataSource = getData().Tables[0];
        }


        DataSet getData()
        {

            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM Account";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);

                connection.Close();
            }

            return data;

        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private bool KiemTra()
        {
            if (txt_TenDN.Text == "" || txt_SoHDX.Text == "" || txt_MaCT.Text == "" || txt_TenHT.Text == "" || txt_MatKhau.Text == "" )
            {
                return false;
            }
            return true;
        }


        private void Reset()
        {
            txt_TenDN.Text = "";
            txt_SoHDX.Text = "";
            txt_MaCT.Text = "";
            txt_TenHT.Text = "";
            txt_MatKhau.Text = "";
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            ComboBox LoaiTK = cbb_Loai;

            if (cbb_Loai.SelectedItem != null)
            {
                string Loai = LoaiTK.SelectedItem.ToString();
                if (KiemTra())
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                    {
                        try
                        {
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            conn.Open();
                            cmd.CommandText = "ThemAC";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@TenDN", SqlDbType.NVarChar).Value = txt_TenDN.Text;
                            cmd.Parameters.Add("@SoHDX", SqlDbType.NVarChar).Value = txt_SoHDX.Text;
                            cmd.Parameters.Add("@MaCT", SqlDbType.NVarChar).Value = txt_MaCT.Text;
                            cmd.Parameters.Add("@Tenhienthi", SqlDbType.NVarChar).Value = txt_TenHT.Text;
                            cmd.Parameters.Add("@Matkhau", SqlDbType.NVarChar).Value = txt_MatKhau.Text;
                            cmd.Parameters.Add("@Loai", SqlDbType.NVarChar).Value = Loai;
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            fTaiKhoan_Load(sender, e);
                            Reset();
                            MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                }
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            ComboBox LoaiTK = cbb_Loai;

            if (cbb_Loai.SelectedItem != null)
            {
                string Loai = LoaiTK.SelectedItem.ToString();
                if (KiemTra())
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                    {
                        try
                        {
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            conn.Open();
                            cmd.CommandText = "SuaAC";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@TenDN", SqlDbType.NVarChar).Value = txt_TenDN.Text;
                            cmd.Parameters.Add("@SoHDX", SqlDbType.NVarChar).Value = txt_SoHDX.Text;
                            cmd.Parameters.Add("@MaCT", SqlDbType.NVarChar).Value = txt_MaCT.Text;
                            cmd.Parameters.Add("@Tenhienthi", SqlDbType.NVarChar).Value = txt_TenHT.Text;
                            cmd.Parameters.Add("@Matkhau", SqlDbType.NVarChar).Value = txt_MatKhau.Text;
                            cmd.Parameters.Add("@Loai", SqlDbType.NVarChar).Value = Loai;
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            fTaiKhoan_Load(sender, e);
                            Reset();
                            MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                }
            }
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            ComboBox LoaiTK = cbb_Loai;

            if (cbb_Loai.SelectedItem != null)
            {
                string Loai = LoaiTK.SelectedItem.ToString();
                if (KiemTra())
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                    {
                        try
                        {
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            conn.Open();
                            cmd.CommandText = "XoaAC";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@TenDN", SqlDbType.NVarChar).Value = txt_TenDN.Text;
                            cmd.Parameters.Add("@SoHDX", SqlDbType.NVarChar).Value = txt_SoHDX.Text;
                            cmd.Parameters.Add("@MaCT", SqlDbType.NVarChar).Value = txt_MaCT.Text;
                            cmd.Parameters.Add("@Tenhienthi", SqlDbType.NVarChar).Value = txt_TenHT.Text;
                            cmd.Parameters.Add("@Matkhau", SqlDbType.NVarChar).Value = txt_MatKhau.Text;
                            cmd.Parameters.Add("@Loai", SqlDbType.NVarChar).Value = Loai;
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            fTaiKhoan_Load(sender, e);
                            Reset();
                            MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                }
            }
        }


    }

}
