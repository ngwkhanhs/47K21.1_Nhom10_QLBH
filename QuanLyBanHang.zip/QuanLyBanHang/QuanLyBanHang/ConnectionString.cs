﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyBanHang
{
    class ConnectionString
    {
        public static string connectionString = @"Data Source=KHANHS\SQLEXPRESS;Initial Catalog=Quanlybanhangcoffeehouse;Integrated Security=True";
    }
}
