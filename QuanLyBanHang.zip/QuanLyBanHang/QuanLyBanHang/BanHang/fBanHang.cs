﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fBanGhe : Form
    {
        public static int TongTien = 0;
        public int SOLUONG;
        public fBanGhe()
        {
            InitializeComponent();
        }

        private void GiaoDienChinh_Load(object sender, EventArgs e)
        {
            load_table();
            load_Menu();
            load_Don();
            TongTien = 0;
        }

        // tạo datareader, khi reader đang chạy, tạo button tương ứng với mỗi bảng ghi 

        DataSet getTable()
        {

            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM BAN";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                //
                connection.Close();
            }

            return data;

        }

        void load_table()
        {
            // Lấy dữ liệu từ cơ sở dữ liệu vào DataSet
            DataSet data = getTable();

            // Xóa các control hiện có trong FlowLayoutPanel
            flp_ban.Controls.Clear();

            // Lặp qua các bản ghi trong DataSet và tạo button cho mỗi bản ghi
            foreach (DataRow row in data.Tables[0].Rows)
            {
                // Lấy thông tin của bàn từ cột tương ứng trong bản ghi
                int tableNumber = Convert.ToInt32(row["SoBan"]);
                string tableStatus = row["Tinhtrang"].ToString();

                // Tạo button cho bàn
                Button tableButton = new Button()
                {
                    Width = 80,
                    Height = 80,
                    Text = "Bàn "+ tableNumber.ToString() + "\n" + tableStatus,
                    Tag = tableNumber  // Lưu trữ số bàn trong thuộc tính Tag của button
                };

                // Gắn sự kiện click cho button

                // Thêm button vào FlowLayoutPanel
                flp_ban.Controls.Add(tableButton);
            }
        }

        string getdrink()
        {
            ComboBox drink = cbb_drink;
            string mon = cbb_drink.SelectedItem.ToString();
            return mon;
        }

        void reset()
        {
            nud_SoLuongMon.Value = 0;
            nud_Ban.Value = 0;
        }

        void load_Don()
        {
            ltv_Don.Columns.Add("Món", 200);
            ltv_Don.Columns.Add("Số lượng");
        }

        private void load_Menu()
        {
            DataSet data = new DataSet();

            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = "select * from MON";
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbb_drink.Items.Add(dr["TenMon"]);

                }

                connection.Close();
            }
            if (cbb_drink.Items.Count > 0)
            {
                cbb_drink.SelectedIndex = 0;
            }
        }

        private void btn_ThemMon_Click(object sender, EventArgs e)
        {
            // Lấy thông tin từ TextBox của Món và Số lượng
            string mon = getdrink();
            int soLuong = (int)nud_SoLuongMon.Value;
            SOLUONG = soLuong;

            // Tạo một ListViewItem từ thông tin vừa lấy
            ListViewItem item = new ListViewItem(mon);
            item.SubItems.Add(soLuong.ToString());
            
            // Thêm ListViewItem vào ListView
            ltv_Don.Items.Add(item);

            // Xóa nội dung cũ
            nud_SoLuongMon.Value = 0;
            
            // Tính tổng tiền
            Tongtien(TinhTien(mon, soLuong));
            txt_TongTien.Text = TongTien.ToString();
        }

        void Tongtien(int tien)
        {
            TongTien = TongTien + tien;
        }

        int TinhTien(string mon, int soluong)
        {
            int tien = new int();
            using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "TinhTien";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@mon", SqlDbType.NVarChar).Value = mon;
                    cmd.Parameters.Add("@soluong", SqlDbType.Int).Value = soluong;

                    // Thêm tham số @tien với ParameterDirection.Output
                    SqlParameter outputParam = new SqlParameter("@tien", SqlDbType.Int);
                    outputParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(outputParam);

                    cmd.Connection = conn;
                    cmd.ExecuteNonQuery();

                    // Lấy giá trị của @matKhau từ tham số
                    string tien_1 = cmd.Parameters["@tien"].Value.ToString();
                    tien = int.Parse(tien_1);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return tien;
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click_1(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Don_Click(object sender, EventArgs e)
        {
            fDonBan f = new fDonBan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_table_Click(object sender, EventArgs e)
        {
            fTinhTrangBan f = new fTinhTrangBan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private bool kiemtra()
        {
            if (nud_Ban.Value == 0 || nud_SoLuongMon.Value == 0)
            {
                return false;
            }
            return true;
        }

        private void btn_ThanhToan_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    cmd.CommandText = "ThemDonBanHangChiTiet";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@ban", SqlDbType.Int).Value = nud_Ban.Value;
                    cmd.Parameters.Add("@tenmon", SqlDbType.NVarChar).Value = cbb_drink.SelectedItem.ToString();
                    cmd.Parameters.Add("@soluong", SqlDbType.Int).Value = SOLUONG;
                    cmd.Parameters.Add("@thanhtien", SqlDbType.Money).Value = TongTien/SOLUONG;

                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Đã tạo đơn thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    reset();
                    GiaoDienChinh_Load(sender, e);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        
    }
}
