﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fDonBan : Form
    {
        public fDonBan()
        {
            InitializeComponent();
        }

        DataSet getData()
        {

            DataSet data = new DataSet();

            // string query
            string query = "select * from DonBanHang";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);


                connection.Close();
            }

            return data;
        }

        private void fDonBan_Load(object sender, EventArgs e)
        {
            dgv_DonBan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_DonBan.DataSource = getData().Tables[0];
        }

        private void btn_Ban_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_table_Click(object sender, EventArgs e)
        {
            fTinhTrangBan f = new fTinhTrangBan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }
    }

    
}
