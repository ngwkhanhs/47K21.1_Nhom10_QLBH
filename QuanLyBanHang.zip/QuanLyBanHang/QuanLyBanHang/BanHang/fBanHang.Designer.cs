﻿namespace QuanLyBanHang
{
    partial class fBanGhe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nud_SoLuongMon = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_table = new System.Windows.Forms.Button();
            this.btn_Don = new System.Windows.Forms.Button();
            this.btn_Ban = new System.Windows.Forms.Button();
            this.flp_ban = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_NhaCC = new System.Windows.Forms.Button();
            this.btn_DatHang = new System.Windows.Forms.Button();
            this.btn_TaiKhoan = new System.Windows.Forms.Button();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_BanHang = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.ltv_Don = new System.Windows.Forms.ListView();
            this.pnl_ThanhToan = new System.Windows.Forms.Panel();
            this.txt_TongTien = new System.Windows.Forms.TextBox();
            this.nud_GopBan = new System.Windows.Forms.NumericUpDown();
            this.nud_Ban = new System.Windows.Forms.NumericUpDown();
            this.btn_TongTien = new System.Windows.Forms.Button();
            this.btn_GopBan = new System.Windows.Forms.Button();
            this.btn_ChuyenBan = new System.Windows.Forms.Button();
            this.btn_ThanhToan = new System.Windows.Forms.Button();
            this.pnl_DatMon = new System.Windows.Forms.Panel();
            this.btn_ThemMon = new System.Windows.Forms.Button();
            this.lbl_SoLuong = new System.Windows.Forms.Label();
            this.cbb_drink = new System.Windows.Forms.ComboBox();
            this.lbl_Mon = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SoLuongMon)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.pnl_ThanhToan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GopBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ban)).BeginInit();
            this.pnl_DatMon.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.menuStrip1);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1233, 38);
            this.panel2.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tàiKhoảnToolStripMenuItem,
            this.adminToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1233, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(98, 29);
            this.tàiKhoảnToolStripMenuItem.Text = "Tài khoản";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(77, 29);
            this.adminToolStripMenuItem.Text = "Admin";
            // 
            // nud_SoLuongMon
            // 
            this.nud_SoLuongMon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_SoLuongMon.Location = new System.Drawing.Point(100, 50);
            this.nud_SoLuongMon.Name = "nud_SoLuongMon";
            this.nud_SoLuongMon.Size = new System.Drawing.Size(92, 30);
            this.nud_SoLuongMon.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.flp_ban);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.pnl_ThanhToan);
            this.panel1.Controls.Add(this.pnl_DatMon);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1244, 596);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_table);
            this.panel4.Controls.Add(this.btn_Don);
            this.panel4.Controls.Add(this.btn_Ban);
            this.panel4.Location = new System.Drawing.Point(184, 52);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(573, 45);
            this.panel4.TabIndex = 6;
            // 
            // btn_table
            // 
            this.btn_table.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btn_table.BackColor = System.Drawing.Color.LightGreen;
            this.btn_table.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_table.Location = new System.Drawing.Point(385, 3);
            this.btn_table.Name = "btn_table";
            this.btn_table.Size = new System.Drawing.Size(185, 39);
            this.btn_table.TabIndex = 2;
            this.btn_table.Text = "Bàn";
            this.btn_table.UseVisualStyleBackColor = false;
            this.btn_table.Click += new System.EventHandler(this.btn_table_Click);
            // 
            // btn_Don
            // 
            this.btn_Don.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Don.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Don.Location = new System.Drawing.Point(194, 3);
            this.btn_Don.Name = "btn_Don";
            this.btn_Don.Size = new System.Drawing.Size(185, 39);
            this.btn_Don.TabIndex = 1;
            this.btn_Don.Text = "Đơn";
            this.btn_Don.UseVisualStyleBackColor = false;
            this.btn_Don.Click += new System.EventHandler(this.btn_Don_Click);
            // 
            // btn_Ban
            // 
            this.btn_Ban.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btn_Ban.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Ban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ban.Location = new System.Drawing.Point(3, 3);
            this.btn_Ban.Name = "btn_Ban";
            this.btn_Ban.Size = new System.Drawing.Size(185, 39);
            this.btn_Ban.TabIndex = 0;
            this.btn_Ban.Text = "Bán";
            this.btn_Ban.UseVisualStyleBackColor = false;
            // 
            // flp_ban
            // 
            this.flp_ban.Location = new System.Drawing.Point(184, 103);
            this.flp_ban.Name = "flp_ban";
            this.flp_ban.Size = new System.Drawing.Size(573, 488);
            this.flp_ban.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_NhaCC);
            this.panel3.Controls.Add(this.btn_DatHang);
            this.panel3.Controls.Add(this.btn_TaiKhoan);
            this.panel3.Controls.Add(this.btn_Menu);
            this.panel3.Controls.Add(this.btn_BanHang);
            this.panel3.Location = new System.Drawing.Point(4, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 545);
            this.panel3.TabIndex = 2;
            // 
            // btn_NhaCC
            // 
            this.btn_NhaCC.BackColor = System.Drawing.Color.LightGreen;
            this.btn_NhaCC.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NhaCC.Location = new System.Drawing.Point(5, 329);
            this.btn_NhaCC.Name = "btn_NhaCC";
            this.btn_NhaCC.Size = new System.Drawing.Size(163, 105);
            this.btn_NhaCC.TabIndex = 4;
            this.btn_NhaCC.Text = "Nhà cung cấp";
            this.btn_NhaCC.UseVisualStyleBackColor = false;
            this.btn_NhaCC.Click += new System.EventHandler(this.btn_NhaCC_Click);
            // 
            // btn_DatHang
            // 
            this.btn_DatHang.BackColor = System.Drawing.Color.LightGreen;
            this.btn_DatHang.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatHang.Location = new System.Drawing.Point(4, 220);
            this.btn_DatHang.Name = "btn_DatHang";
            this.btn_DatHang.Size = new System.Drawing.Size(163, 105);
            this.btn_DatHang.TabIndex = 1;
            this.btn_DatHang.Text = "Đặt hàng";
            this.btn_DatHang.UseVisualStyleBackColor = false;
            this.btn_DatHang.Click += new System.EventHandler(this.btn_DatHang_Click);
            // 
            // btn_TaiKhoan
            // 
            this.btn_TaiKhoan.BackColor = System.Drawing.Color.LightGreen;
            this.btn_TaiKhoan.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TaiKhoan.Location = new System.Drawing.Point(4, 437);
            this.btn_TaiKhoan.Name = "btn_TaiKhoan";
            this.btn_TaiKhoan.Size = new System.Drawing.Size(163, 105);
            this.btn_TaiKhoan.TabIndex = 3;
            this.btn_TaiKhoan.Text = "Tài khoản";
            this.btn_TaiKhoan.UseVisualStyleBackColor = false;
            this.btn_TaiKhoan.Click += new System.EventHandler(this.btn_TaiKhoan_Click);
            // 
            // btn_Menu
            // 
            this.btn_Menu.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Menu.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(5, 112);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(162, 105);
            this.btn_Menu.TabIndex = 2;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = false;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click_1);
            // 
            // btn_BanHang
            // 
            this.btn_BanHang.BackColor = System.Drawing.Color.LightGreen;
            this.btn_BanHang.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BanHang.Location = new System.Drawing.Point(4, 3);
            this.btn_BanHang.Name = "btn_BanHang";
            this.btn_BanHang.Size = new System.Drawing.Size(162, 105);
            this.btn_BanHang.TabIndex = 0;
            this.btn_BanHang.Text = "Bán hàng";
            this.btn_BanHang.UseVisualStyleBackColor = false;
            this.btn_BanHang.Click += new System.EventHandler(this.btn_BanHang_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.ltv_Don);
            this.panel6.Location = new System.Drawing.Point(763, 144);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(474, 346);
            this.panel6.TabIndex = 3;
            // 
            // ltv_Don
            // 
            this.ltv_Don.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ltv_Don.GridLines = true;
            this.ltv_Don.Location = new System.Drawing.Point(0, 1);
            this.ltv_Don.Name = "ltv_Don";
            this.ltv_Don.Size = new System.Drawing.Size(471, 342);
            this.ltv_Don.TabIndex = 0;
            this.ltv_Don.UseCompatibleStateImageBehavior = false;
            this.ltv_Don.View = System.Windows.Forms.View.Details;
            // 
            // pnl_ThanhToan
            // 
            this.pnl_ThanhToan.Controls.Add(this.txt_TongTien);
            this.pnl_ThanhToan.Controls.Add(this.nud_GopBan);
            this.pnl_ThanhToan.Controls.Add(this.nud_Ban);
            this.pnl_ThanhToan.Controls.Add(this.btn_TongTien);
            this.pnl_ThanhToan.Controls.Add(this.btn_GopBan);
            this.pnl_ThanhToan.Controls.Add(this.btn_ChuyenBan);
            this.pnl_ThanhToan.Controls.Add(this.btn_ThanhToan);
            this.pnl_ThanhToan.Location = new System.Drawing.Point(763, 496);
            this.pnl_ThanhToan.Name = "pnl_ThanhToan";
            this.pnl_ThanhToan.Size = new System.Drawing.Size(474, 97);
            this.pnl_ThanhToan.TabIndex = 4;
            // 
            // txt_TongTien
            // 
            this.txt_TongTien.Location = new System.Drawing.Point(222, 56);
            this.txt_TongTien.Name = "txt_TongTien";
            this.txt_TongTien.ReadOnly = true;
            this.txt_TongTien.Size = new System.Drawing.Size(135, 26);
            this.txt_TongTien.TabIndex = 7;
            this.txt_TongTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_GopBan
            // 
            this.nud_GopBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_GopBan.Location = new System.Drawing.Point(112, 55);
            this.nud_GopBan.Name = "nud_GopBan";
            this.nud_GopBan.Size = new System.Drawing.Size(104, 30);
            this.nud_GopBan.TabIndex = 6;
            // 
            // nud_Ban
            // 
            this.nud_Ban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_Ban.Location = new System.Drawing.Point(4, 55);
            this.nud_Ban.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_Ban.Name = "nud_Ban";
            this.nud_Ban.Size = new System.Drawing.Size(104, 30);
            this.nud_Ban.TabIndex = 2;
            // 
            // btn_TongTien
            // 
            this.btn_TongTien.BackColor = System.Drawing.Color.LightGreen;
            this.btn_TongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TongTien.ForeColor = System.Drawing.Color.Black;
            this.btn_TongTien.Location = new System.Drawing.Point(222, 14);
            this.btn_TongTien.Name = "btn_TongTien";
            this.btn_TongTien.Size = new System.Drawing.Size(135, 35);
            this.btn_TongTien.TabIndex = 5;
            this.btn_TongTien.Text = "Tổng tiền";
            this.btn_TongTien.UseVisualStyleBackColor = false;
            // 
            // btn_GopBan
            // 
            this.btn_GopBan.BackColor = System.Drawing.Color.LightGreen;
            this.btn_GopBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GopBan.ForeColor = System.Drawing.Color.Black;
            this.btn_GopBan.Location = new System.Drawing.Point(112, 14);
            this.btn_GopBan.Name = "btn_GopBan";
            this.btn_GopBan.Size = new System.Drawing.Size(104, 35);
            this.btn_GopBan.TabIndex = 4;
            this.btn_GopBan.Text = "Gộp bàn";
            this.btn_GopBan.UseVisualStyleBackColor = false;
            // 
            // btn_ChuyenBan
            // 
            this.btn_ChuyenBan.BackColor = System.Drawing.Color.LightGreen;
            this.btn_ChuyenBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ChuyenBan.ForeColor = System.Drawing.Color.Black;
            this.btn_ChuyenBan.Location = new System.Drawing.Point(4, 14);
            this.btn_ChuyenBan.Name = "btn_ChuyenBan";
            this.btn_ChuyenBan.Size = new System.Drawing.Size(104, 35);
            this.btn_ChuyenBan.TabIndex = 3;
            this.btn_ChuyenBan.Text = "Bàn";
            this.btn_ChuyenBan.UseVisualStyleBackColor = false;
            // 
            // btn_ThanhToan
            // 
            this.btn_ThanhToan.BackColor = System.Drawing.Color.LightGreen;
            this.btn_ThanhToan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThanhToan.ForeColor = System.Drawing.Color.Black;
            this.btn_ThanhToan.Location = new System.Drawing.Point(363, 6);
            this.btn_ThanhToan.Name = "btn_ThanhToan";
            this.btn_ThanhToan.Size = new System.Drawing.Size(103, 80);
            this.btn_ThanhToan.TabIndex = 2;
            this.btn_ThanhToan.Text = "Thanh toán";
            this.btn_ThanhToan.UseVisualStyleBackColor = false;
            this.btn_ThanhToan.Click += new System.EventHandler(this.btn_ThanhToan_Click);
            // 
            // pnl_DatMon
            // 
            this.pnl_DatMon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_DatMon.Controls.Add(this.btn_ThemMon);
            this.pnl_DatMon.Controls.Add(this.nud_SoLuongMon);
            this.pnl_DatMon.Controls.Add(this.lbl_SoLuong);
            this.pnl_DatMon.Controls.Add(this.cbb_drink);
            this.pnl_DatMon.Controls.Add(this.lbl_Mon);
            this.pnl_DatMon.Location = new System.Drawing.Point(763, 48);
            this.pnl_DatMon.Name = "pnl_DatMon";
            this.pnl_DatMon.Size = new System.Drawing.Size(474, 90);
            this.pnl_DatMon.TabIndex = 2;
            // 
            // btn_ThemMon
            // 
            this.btn_ThemMon.BackColor = System.Drawing.Color.LightGreen;
            this.btn_ThemMon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThemMon.ForeColor = System.Drawing.Color.Black;
            this.btn_ThemMon.Location = new System.Drawing.Point(369, 3);
            this.btn_ThemMon.Name = "btn_ThemMon";
            this.btn_ThemMon.Size = new System.Drawing.Size(97, 80);
            this.btn_ThemMon.TabIndex = 0;
            this.btn_ThemMon.Text = "Thêm món";
            this.btn_ThemMon.UseVisualStyleBackColor = false;
            this.btn_ThemMon.Click += new System.EventHandler(this.btn_ThemMon_Click);
            // 
            // lbl_SoLuong
            // 
            this.lbl_SoLuong.AutoSize = true;
            this.lbl_SoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SoLuong.Location = new System.Drawing.Point(4, 55);
            this.lbl_SoLuong.Name = "lbl_SoLuong";
            this.lbl_SoLuong.Size = new System.Drawing.Size(90, 25);
            this.lbl_SoLuong.TabIndex = 1;
            this.lbl_SoLuong.Text = "Số lượng";
            // 
            // cbb_drink
            // 
            this.cbb_drink.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_drink.FormattingEnabled = true;
            this.cbb_drink.Location = new System.Drawing.Point(100, 9);
            this.cbb_drink.Name = "cbb_drink";
            this.cbb_drink.Size = new System.Drawing.Size(247, 33);
            this.cbb_drink.TabIndex = 0;
            // 
            // lbl_Mon
            // 
            this.lbl_Mon.AutoSize = true;
            this.lbl_Mon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mon.Location = new System.Drawing.Point(4, 14);
            this.lbl_Mon.Name = "lbl_Mon";
            this.lbl_Mon.Size = new System.Drawing.Size(51, 25);
            this.lbl_Mon.TabIndex = 0;
            this.lbl_Mon.Text = "Món";
            // 
            // fBanGhe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1264, 623);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fBanGhe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bán hàng";
            this.Load += new System.EventHandler(this.GiaoDienChinh_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SoLuongMon)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.pnl_ThanhToan.ResumeLayout(false);
            this.pnl_ThanhToan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GopBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ban)).EndInit();
            this.pnl_DatMon.ResumeLayout(false);
            this.pnl_DatMon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_ThanhToan;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel pnl_DatMon;
        private System.Windows.Forms.NumericUpDown nud_SoLuongMon;
        private System.Windows.Forms.ComboBox cbb_drink;
        private System.Windows.Forms.Label lbl_SoLuong;
        private System.Windows.Forms.Label lbl_Mon;
        private System.Windows.Forms.Button btn_ThemMon;
        private System.Windows.Forms.Button btn_ThanhToan;
        private System.Windows.Forms.Button btn_ChuyenBan;
        private System.Windows.Forms.Button btn_GopBan;
        private System.Windows.Forms.NumericUpDown nud_GopBan;
        private System.Windows.Forms.NumericUpDown nud_Ban;
        private System.Windows.Forms.Button btn_TongTien;
        private System.Windows.Forms.TextBox txt_TongTien;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_NhaCC;
        private System.Windows.Forms.Button btn_DatHang;
        private System.Windows.Forms.Button btn_TaiKhoan;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Button btn_BanHang;
        private System.Windows.Forms.FlowLayoutPanel flp_ban;
        private System.Windows.Forms.ListView ltv_Don;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_Don;
        private System.Windows.Forms.Button btn_Ban;
        private System.Windows.Forms.Button btn_table;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;

    }
}