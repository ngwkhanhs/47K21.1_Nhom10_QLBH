﻿namespace QuanLyBanHang
{
    partial class fTinhTrangBan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_ThayDoi = new System.Windows.Forms.Button();
            this.cbb_tinhtrang = new System.Windows.Forms.ComboBox();
            this.nud_soban = new System.Windows.Forms.NumericUpDown();
            this.lbl_TinhTrang = new System.Windows.Forms.Label();
            this.lbl_SoBan = new System.Windows.Forms.Label();
            this.flp_ban = new System.Windows.Forms.FlowLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_table = new System.Windows.Forms.Button();
            this.btn_Don = new System.Windows.Forms.Button();
            this.btn_Ban = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_NhaCC = new System.Windows.Forms.Button();
            this.btn_DatHang = new System.Windows.Forms.Button();
            this.btn_TaiKhoan = new System.Windows.Forms.Button();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_BanHang = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_soban)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.flp_ban);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(10, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1244, 596);
            this.panel1.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.btn_ThayDoi);
            this.panel5.Controls.Add(this.cbb_tinhtrang);
            this.panel5.Controls.Add(this.nud_soban);
            this.panel5.Controls.Add(this.lbl_TinhTrang);
            this.panel5.Controls.Add(this.lbl_SoBan);
            this.panel5.Location = new System.Drawing.Point(764, 55);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(473, 536);
            this.panel5.TabIndex = 8;
            // 
            // btn_ThayDoi
            // 
            this.btn_ThayDoi.BackColor = System.Drawing.Color.LightGreen;
            this.btn_ThayDoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThayDoi.Location = new System.Drawing.Point(138, 143);
            this.btn_ThayDoi.Name = "btn_ThayDoi";
            this.btn_ThayDoi.Size = new System.Drawing.Size(137, 45);
            this.btn_ThayDoi.TabIndex = 4;
            this.btn_ThayDoi.Text = "Thay đổi";
            this.btn_ThayDoi.UseVisualStyleBackColor = false;
            this.btn_ThayDoi.Click += new System.EventHandler(this.btn_ThayDoi_Click);
            // 
            // cbb_tinhtrang
            // 
            this.cbb_tinhtrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_tinhtrang.FormattingEnabled = true;
            this.cbb_tinhtrang.Items.AddRange(new object[] {
            "Trống",
            "Có người"});
            this.cbb_tinhtrang.Location = new System.Drawing.Point(138, 81);
            this.cbb_tinhtrang.Name = "cbb_tinhtrang";
            this.cbb_tinhtrang.Size = new System.Drawing.Size(318, 33);
            this.cbb_tinhtrang.TabIndex = 3;
            // 
            // nud_soban
            // 
            this.nud_soban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_soban.Location = new System.Drawing.Point(138, 18);
            this.nud_soban.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_soban.Name = "nud_soban";
            this.nud_soban.Size = new System.Drawing.Size(318, 30);
            this.nud_soban.TabIndex = 2;
            this.nud_soban.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_TinhTrang
            // 
            this.lbl_TinhTrang.AutoSize = true;
            this.lbl_TinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TinhTrang.Location = new System.Drawing.Point(16, 84);
            this.lbl_TinhTrang.Name = "lbl_TinhTrang";
            this.lbl_TinhTrang.Size = new System.Drawing.Size(100, 25);
            this.lbl_TinhTrang.TabIndex = 1;
            this.lbl_TinhTrang.Text = "Tình trạng";
            // 
            // lbl_SoBan
            // 
            this.lbl_SoBan.AutoSize = true;
            this.lbl_SoBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SoBan.Location = new System.Drawing.Point(16, 18);
            this.lbl_SoBan.Name = "lbl_SoBan";
            this.lbl_SoBan.Size = new System.Drawing.Size(75, 25);
            this.lbl_SoBan.TabIndex = 0;
            this.lbl_SoBan.Text = "Số bàn";
            // 
            // flp_ban
            // 
            this.flp_ban.Location = new System.Drawing.Point(187, 104);
            this.flp_ban.Name = "flp_ban";
            this.flp_ban.Size = new System.Drawing.Size(570, 487);
            this.flp_ban.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_table);
            this.panel4.Controls.Add(this.btn_Don);
            this.panel4.Controls.Add(this.btn_Ban);
            this.panel4.Location = new System.Drawing.Point(184, 52);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(573, 45);
            this.panel4.TabIndex = 6;
            // 
            // btn_table
            // 
            this.btn_table.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btn_table.BackColor = System.Drawing.Color.LightGreen;
            this.btn_table.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_table.Location = new System.Drawing.Point(385, 3);
            this.btn_table.Name = "btn_table";
            this.btn_table.Size = new System.Drawing.Size(185, 39);
            this.btn_table.TabIndex = 2;
            this.btn_table.Text = "Bàn";
            this.btn_table.UseVisualStyleBackColor = false;
            // 
            // btn_Don
            // 
            this.btn_Don.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Don.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Don.Location = new System.Drawing.Point(194, 3);
            this.btn_Don.Name = "btn_Don";
            this.btn_Don.Size = new System.Drawing.Size(185, 39);
            this.btn_Don.TabIndex = 1;
            this.btn_Don.Text = "Đơn";
            this.btn_Don.UseVisualStyleBackColor = false;
            this.btn_Don.Click += new System.EventHandler(this.btn_Don_Click);
            // 
            // btn_Ban
            // 
            this.btn_Ban.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btn_Ban.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Ban.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ban.Location = new System.Drawing.Point(3, 3);
            this.btn_Ban.Name = "btn_Ban";
            this.btn_Ban.Size = new System.Drawing.Size(185, 39);
            this.btn_Ban.TabIndex = 0;
            this.btn_Ban.Text = "Bán";
            this.btn_Ban.UseVisualStyleBackColor = false;
            this.btn_Ban.Click += new System.EventHandler(this.btn_Ban_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_NhaCC);
            this.panel3.Controls.Add(this.btn_DatHang);
            this.panel3.Controls.Add(this.btn_TaiKhoan);
            this.panel3.Controls.Add(this.btn_Menu);
            this.panel3.Controls.Add(this.btn_BanHang);
            this.panel3.Location = new System.Drawing.Point(4, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 545);
            this.panel3.TabIndex = 2;
            // 
            // btn_NhaCC
            // 
            this.btn_NhaCC.BackColor = System.Drawing.Color.LightGreen;
            this.btn_NhaCC.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NhaCC.Location = new System.Drawing.Point(5, 329);
            this.btn_NhaCC.Name = "btn_NhaCC";
            this.btn_NhaCC.Size = new System.Drawing.Size(163, 105);
            this.btn_NhaCC.TabIndex = 4;
            this.btn_NhaCC.Text = "Nhà cung cấp";
            this.btn_NhaCC.UseVisualStyleBackColor = false;
            this.btn_NhaCC.Click += new System.EventHandler(this.btn_NhaCC_Click);
            // 
            // btn_DatHang
            // 
            this.btn_DatHang.BackColor = System.Drawing.Color.LightGreen;
            this.btn_DatHang.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatHang.Location = new System.Drawing.Point(4, 220);
            this.btn_DatHang.Name = "btn_DatHang";
            this.btn_DatHang.Size = new System.Drawing.Size(163, 105);
            this.btn_DatHang.TabIndex = 1;
            this.btn_DatHang.Text = "Đặt hàng";
            this.btn_DatHang.UseVisualStyleBackColor = false;
            this.btn_DatHang.Click += new System.EventHandler(this.btn_DatHang_Click);
            // 
            // btn_TaiKhoan
            // 
            this.btn_TaiKhoan.BackColor = System.Drawing.Color.LightGreen;
            this.btn_TaiKhoan.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TaiKhoan.Location = new System.Drawing.Point(4, 437);
            this.btn_TaiKhoan.Name = "btn_TaiKhoan";
            this.btn_TaiKhoan.Size = new System.Drawing.Size(163, 105);
            this.btn_TaiKhoan.TabIndex = 3;
            this.btn_TaiKhoan.Text = "Tài khoản";
            this.btn_TaiKhoan.UseVisualStyleBackColor = false;
            this.btn_TaiKhoan.Click += new System.EventHandler(this.btn_TaiKhoan_Click);
            // 
            // btn_Menu
            // 
            this.btn_Menu.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Menu.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(5, 112);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(162, 105);
            this.btn_Menu.TabIndex = 2;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = false;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // btn_BanHang
            // 
            this.btn_BanHang.BackColor = System.Drawing.Color.LightGreen;
            this.btn_BanHang.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BanHang.Location = new System.Drawing.Point(4, 3);
            this.btn_BanHang.Name = "btn_BanHang";
            this.btn_BanHang.Size = new System.Drawing.Size(162, 105);
            this.btn_BanHang.TabIndex = 0;
            this.btn_BanHang.Text = "Bán hàng";
            this.btn_BanHang.UseVisualStyleBackColor = false;
            this.btn_BanHang.Click += new System.EventHandler(this.btn_BanHang_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.menuStrip1);
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1233, 38);
            this.panel2.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tàiKhoảnToolStripMenuItem,
            this.adminToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1233, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(98, 29);
            this.tàiKhoảnToolStripMenuItem.Text = "Tài khoản";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(77, 29);
            this.adminToolStripMenuItem.Text = "Admin";
            // 
            // fTinhTrangBan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1264, 623);
            this.Controls.Add(this.panel1);
            this.Name = "fTinhTrangBan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tình trạng bàn";
            this.Load += new System.EventHandler(this.fTinhTrangBan_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_soban)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.FlowLayoutPanel flp_ban;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_table;
        private System.Windows.Forms.Button btn_Don;
        private System.Windows.Forms.Button btn_Ban;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_NhaCC;
        private System.Windows.Forms.Button btn_DatHang;
        private System.Windows.Forms.Button btn_TaiKhoan;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Button btn_BanHang;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ComboBox cbb_tinhtrang;
        private System.Windows.Forms.NumericUpDown nud_soban;
        private System.Windows.Forms.Label lbl_TinhTrang;
        private System.Windows.Forms.Label lbl_SoBan;
        private System.Windows.Forms.Button btn_ThayDoi;
    }
}