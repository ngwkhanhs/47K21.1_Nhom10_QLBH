﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fTinhTrangBan : Form
    {
        public fTinhTrangBan()
        {
            InitializeComponent();
        }

        private void fTinhTrangBan_Load(object sender, EventArgs e)
        {
            load_table();
        }

        DataSet getTable()
        {

            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM BAN";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);
                //
                connection.Close();
            }

            return data;

        }

        void load_table()
        {
            // Lấy dữ liệu từ cơ sở dữ liệu vào DataSet
            DataSet data = getTable();

            // Xóa các control hiện có trong FlowLayoutPanel
            flp_ban.Controls.Clear();

            // Lặp qua các bản ghi trong DataSet và tạo button cho mỗi bản ghi
            foreach (DataRow row in data.Tables[0].Rows)
            {
                // Lấy thông tin của bàn từ cột tương ứng trong bản ghi
                int tableNumber = Convert.ToInt32(row["SoBan"]);
                string tableStatus = row["Tinhtrang"].ToString();

                // Tạo button cho bàn
                Button tableButton = new Button()
                {
                    Width = 80,
                    Height = 80,
                    Text = "Bàn " + tableNumber.ToString() + "\n" + tableStatus,
                    Tag = tableNumber  // Lưu trữ số bàn trong thuộc tính Tag của button
                };

                // Thêm button vào FlowLayoutPanel
                flp_ban.Controls.Add(tableButton);
            }
        }

        private void btn_ThayDoi_Click(object sender, EventArgs e)
        {
            ComboBox Ban = cbb_tinhtrang;

            if (cbb_tinhtrang.SelectedItem != null)
            {
                string TinhTrang = Ban.SelectedItem.ToString();
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        conn.Open();
                        cmd.CommandText = "tinhtrang_ban";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@soban", SqlDbType.Int).Value = nud_soban.Value;
                        cmd.Parameters.Add("@tinhtrang", SqlDbType.NVarChar).Value = TinhTrang;
      
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fTinhTrangBan_Load(sender, e);
                        nud_soban.Value = 0;
                        MessageBox.Show("Đã thay đổi thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void btn_Ban_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Don_Click(object sender, EventArgs e)
        {
            fDonBan f = new fDonBan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }




    }
}
