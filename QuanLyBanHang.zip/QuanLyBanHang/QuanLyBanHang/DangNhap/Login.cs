﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            // KiemTra_KhongPhongChongSqli();
            KiemTra();
        }


        private void KiemTra()
        {
            int check = 0;
            if (txt_username.Text == "" || txt_password.Text == "")
            {
                Login f = new Login();
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
            else
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "DangNhap";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@tenDN", SqlDbType.NVarChar) { Value = txt_username.Text });
                        cmd.Parameters.Add(new SqlParameter("@matKhau", SqlDbType.Int) { Value = Convert.ToInt32(txt_password.Text) });

                        // Thêm tham số @ret với ParameterDirection.Output
                        SqlParameter output = new SqlParameter("@ret", SqlDbType.Int) { Direction = ParameterDirection.Output };
                        cmd.Parameters.Add(output);

                        cmd.Connection = conn;
                        cmd.Prepare(); // Sử dụng Prepared Statements

                        cmd.ExecuteNonQuery();

                        // Lấy giá trị của @ret từ tham số
                        check = Convert.ToInt32(cmd.Parameters["@ret"].Value);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                if (check == 1)
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    load_banhang();
                }
                else if (check == 0)
                {
                    MessageBox.Show("Đăng nhập thất bại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        ///// CHƯA PHÒNG SQLI /////////

        /* 
         
        private void KiemTra_KhongPhongChongSqli()
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
            {
                try
                {
                    conn.Open();
                    var query = "select * from Account where TenDN='" + txt_username.Text + "' and Matkhau= '" + txt_password.Text + "'";

                    var cmd = new SqlCommand(query, conn);
                    var dr = cmd.ExecuteReader();
                    if (dr.Read() == true)
                    {
                        MessageBox.Show("Đăng nhập thành công!", "Thông báo");
                        load_banhang();
                    }
                    else
                    {
                        MessageBox.Show("Lỗi đăng nhập!", "Thông báo");
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
         
         */

        void load_banhang()
        {
            
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát khỏi phần mềm?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }


    }
}
