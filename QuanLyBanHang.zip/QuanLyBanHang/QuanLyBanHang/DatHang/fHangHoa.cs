﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fHangHoa : Form
    {
        public fHangHoa()
        {
            InitializeComponent();
        }

        private void fHangHoa_Load(object sender, EventArgs e)
        {
            dgv_HangHoa.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_HangHoa.DataSource = getData().Tables[0];
        }

        DataSet getData()
        {

            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM HANGHOA";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);


                connection.Close();
            }

            return data;
        }


        private void btn_Dat_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatChiTiet_Click(object sender, EventArgs e)
        {
            fDatChiTiet f = new fDatChiTiet();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_HangHoa_Click(object sender, EventArgs e)
        {
            fHangHoa f = new fHangHoa();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NguoiDatHang_Click(object sender, EventArgs e)
        {
            fNguoiDH f = new fNguoiDH();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private bool KiemTra()
        {
            if (txt_MaHang.Text == "" || txt_TenHang.Text == "" || txt_DonVi.Text == "" || txt_DonGia.Text == "" || txt_GiamGia.Text == "")
            {
                return false;
            }
            return true;
        }

        private void Reset()
        {
            txt_MaHang.Text = "";
            txt_TenHang.Text = "";
            txt_DonVi.Text = "";
            txt_DonGia.Text = "";
            txt_GiamGia.Text = "";
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "ThemHH";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Mahang", SqlDbType.NVarChar).Value = txt_MaHang.Text;
                        cmd.Parameters.Add("@Tenhang", SqlDbType.NVarChar).Value = txt_TenHang.Text;
                        cmd.Parameters.Add("@Donvi", SqlDbType.NVarChar).Value = txt_DonVi.Text;
                        cmd.Parameters.Add("@Dongia", SqlDbType.NVarChar).Value = txt_DonGia.Text;
                        cmd.Parameters.Add("@Giamgia", SqlDbType.NVarChar).Value = txt_GiamGia.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fHangHoa_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "SuaHH";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Mahang", SqlDbType.NVarChar).Value = txt_MaHang.Text;
                        cmd.Parameters.Add("@Tenhang", SqlDbType.NVarChar).Value = txt_TenHang.Text;
                        cmd.Parameters.Add("@Donvi", SqlDbType.NVarChar).Value = txt_DonVi.Text;
                        cmd.Parameters.Add("@Dongia", SqlDbType.NVarChar).Value = txt_DonGia.Text;
                        cmd.Parameters.Add("@Giamgia", SqlDbType.NVarChar).Value = txt_GiamGia.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fHangHoa_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã sửa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "XoaHH";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@Mahang", SqlDbType.NVarChar).Value = txt_MaHang.Text;
                        cmd.Parameters.Add("@Tenhang", SqlDbType.NVarChar).Value = txt_TenHang.Text;
                        cmd.Parameters.Add("@Donvi", SqlDbType.NVarChar).Value = txt_DonVi.Text;
                        cmd.Parameters.Add("@Dongia", SqlDbType.NVarChar).Value = txt_DonGia.Text;
                        cmd.Parameters.Add("@Giamgia", SqlDbType.NVarChar).Value = txt_GiamGia.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fHangHoa_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }


    }
}
