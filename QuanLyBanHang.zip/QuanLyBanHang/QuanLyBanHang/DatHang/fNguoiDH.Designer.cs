﻿namespace QuanLyBanHang
{
    partial class fNguoiDH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_account = new System.Windows.Forms.Panel();
            this.mns_account = new System.Windows.Forms.MenuStrip();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_NhaCC = new System.Windows.Forms.Button();
            this.btn_DatHang = new System.Windows.Forms.Button();
            this.btn_TaiKhoan = new System.Windows.Forms.Button();
            this.btn_Menu = new System.Windows.Forms.Button();
            this.btn_BanHang = new System.Windows.Forms.Button();
            this.pnl_DatMon = new System.Windows.Forms.Panel();
            this.btn_Xoa = new System.Windows.Forms.Button();
            this.btn_Them = new System.Windows.Forms.Button();
            this.btn_Sua = new System.Windows.Forms.Button();
            this.btn_TimKiem = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dgv_NguoiDH = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_DiaChi = new System.Windows.Forms.TextBox();
            this.txt_TenND = new System.Windows.Forms.TextBox();
            this.txt_SDT = new System.Windows.Forms.TextBox();
            this.lbl_SDT = new System.Windows.Forms.Label();
            this.lbl_DiaChi = new System.Windows.Forms.Label();
            this.txt_MaND = new System.Windows.Forms.TextBox();
            this.lbl_TenND = new System.Windows.Forms.Label();
            this.lbl_MaND = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_HangHoa = new System.Windows.Forms.Button();
            this.btn_NguoiDatHang = new System.Windows.Forms.Button();
            this.btn_DatChiTiet = new System.Windows.Forms.Button();
            this.btn_Dat = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnl_account.SuspendLayout();
            this.mns_account.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnl_DatMon.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_NguoiDH)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_account
            // 
            this.pnl_account.Controls.Add(this.mns_account);
            this.pnl_account.Location = new System.Drawing.Point(4, 4);
            this.pnl_account.Name = "pnl_account";
            this.pnl_account.Size = new System.Drawing.Size(1233, 38);
            this.pnl_account.TabIndex = 0;
            // 
            // mns_account
            // 
            this.mns_account.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.mns_account.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tàiKhoảnToolStripMenuItem,
            this.adminToolStripMenuItem});
            this.mns_account.Location = new System.Drawing.Point(0, 0);
            this.mns_account.Name = "mns_account";
            this.mns_account.Size = new System.Drawing.Size(1233, 33);
            this.mns_account.TabIndex = 0;
            this.mns_account.Text = "menuStrip1";
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(98, 29);
            this.tàiKhoảnToolStripMenuItem.Text = "Tài khoản";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(77, 29);
            this.adminToolStripMenuItem.Text = "Admin";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_NhaCC);
            this.panel3.Controls.Add(this.btn_DatHang);
            this.panel3.Controls.Add(this.btn_TaiKhoan);
            this.panel3.Controls.Add(this.btn_Menu);
            this.panel3.Controls.Add(this.btn_BanHang);
            this.panel3.Location = new System.Drawing.Point(4, 48);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 545);
            this.panel3.TabIndex = 1;
            // 
            // btn_NhaCC
            // 
            this.btn_NhaCC.BackColor = System.Drawing.Color.LightGreen;
            this.btn_NhaCC.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NhaCC.Location = new System.Drawing.Point(5, 329);
            this.btn_NhaCC.Name = "btn_NhaCC";
            this.btn_NhaCC.Size = new System.Drawing.Size(163, 105);
            this.btn_NhaCC.TabIndex = 4;
            this.btn_NhaCC.Text = "Nhà cung cấp";
            this.btn_NhaCC.UseVisualStyleBackColor = false;
            this.btn_NhaCC.Click += new System.EventHandler(this.btn_NhaCC_Click);
            // 
            // btn_DatHang
            // 
            this.btn_DatHang.BackColor = System.Drawing.Color.LightGreen;
            this.btn_DatHang.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatHang.Location = new System.Drawing.Point(4, 220);
            this.btn_DatHang.Name = "btn_DatHang";
            this.btn_DatHang.Size = new System.Drawing.Size(163, 105);
            this.btn_DatHang.TabIndex = 1;
            this.btn_DatHang.Text = "Đặt hàng";
            this.btn_DatHang.UseVisualStyleBackColor = false;
            this.btn_DatHang.Click += new System.EventHandler(this.btn_DatHang_Click);
            // 
            // btn_TaiKhoan
            // 
            this.btn_TaiKhoan.BackColor = System.Drawing.Color.LightGreen;
            this.btn_TaiKhoan.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TaiKhoan.Location = new System.Drawing.Point(4, 437);
            this.btn_TaiKhoan.Name = "btn_TaiKhoan";
            this.btn_TaiKhoan.Size = new System.Drawing.Size(163, 105);
            this.btn_TaiKhoan.TabIndex = 3;
            this.btn_TaiKhoan.Text = "Tài khoản";
            this.btn_TaiKhoan.UseVisualStyleBackColor = false;
            this.btn_TaiKhoan.Click += new System.EventHandler(this.btn_TaiKhoan_Click);
            // 
            // btn_Menu
            // 
            this.btn_Menu.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Menu.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Menu.Location = new System.Drawing.Point(5, 112);
            this.btn_Menu.Name = "btn_Menu";
            this.btn_Menu.Size = new System.Drawing.Size(162, 105);
            this.btn_Menu.TabIndex = 2;
            this.btn_Menu.Text = "Menu";
            this.btn_Menu.UseVisualStyleBackColor = false;
            this.btn_Menu.Click += new System.EventHandler(this.btn_Menu_Click);
            // 
            // btn_BanHang
            // 
            this.btn_BanHang.BackColor = System.Drawing.Color.LightGreen;
            this.btn_BanHang.Font = new System.Drawing.Font("Arial Narrow", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BanHang.Location = new System.Drawing.Point(4, 3);
            this.btn_BanHang.Name = "btn_BanHang";
            this.btn_BanHang.Size = new System.Drawing.Size(162, 105);
            this.btn_BanHang.TabIndex = 0;
            this.btn_BanHang.Text = "Bán hàng";
            this.btn_BanHang.UseVisualStyleBackColor = false;
            this.btn_BanHang.Click += new System.EventHandler(this.btn_BanHang_Click);
            // 
            // pnl_DatMon
            // 
            this.pnl_DatMon.Controls.Add(this.btn_Xoa);
            this.pnl_DatMon.Controls.Add(this.btn_Them);
            this.pnl_DatMon.Controls.Add(this.btn_Sua);
            this.pnl_DatMon.Controls.Add(this.btn_TimKiem);
            this.pnl_DatMon.Location = new System.Drawing.Point(867, 465);
            this.pnl_DatMon.Name = "pnl_DatMon";
            this.pnl_DatMon.Size = new System.Drawing.Size(374, 125);
            this.pnl_DatMon.TabIndex = 2;
            // 
            // btn_Xoa
            // 
            this.btn_Xoa.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Xoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Xoa.Location = new System.Drawing.Point(195, 67);
            this.btn_Xoa.Name = "btn_Xoa";
            this.btn_Xoa.Size = new System.Drawing.Size(176, 55);
            this.btn_Xoa.TabIndex = 3;
            this.btn_Xoa.Text = "Xóa";
            this.btn_Xoa.UseVisualStyleBackColor = false;
            this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Them.Location = new System.Drawing.Point(194, 6);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(176, 55);
            this.btn_Them.TabIndex = 2;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.UseVisualStyleBackColor = false;
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // btn_Sua
            // 
            this.btn_Sua.BackColor = System.Drawing.Color.LightGreen;
            this.btn_Sua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sua.Location = new System.Drawing.Point(3, 67);
            this.btn_Sua.Name = "btn_Sua";
            this.btn_Sua.Size = new System.Drawing.Size(176, 55);
            this.btn_Sua.TabIndex = 1;
            this.btn_Sua.Text = "Sửa";
            this.btn_Sua.UseVisualStyleBackColor = false;
            this.btn_Sua.Click += new System.EventHandler(this.btn_Sua_Click);
            // 
            // btn_TimKiem
            // 
            this.btn_TimKiem.BackColor = System.Drawing.Color.LightGreen;
            this.btn_TimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TimKiem.Location = new System.Drawing.Point(0, 6);
            this.btn_TimKiem.Name = "btn_TimKiem";
            this.btn_TimKiem.Size = new System.Drawing.Size(179, 55);
            this.btn_TimKiem.TabIndex = 0;
            this.btn_TimKiem.Text = "Tìm kiếm";
            this.btn_TimKiem.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dgv_NguoiDH);
            this.panel4.Location = new System.Drawing.Point(183, 112);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(678, 478);
            this.panel4.TabIndex = 5;
            // 
            // dgv_NguoiDH
            // 
            this.dgv_NguoiDH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_NguoiDH.Location = new System.Drawing.Point(4, 4);
            this.dgv_NguoiDH.Name = "dgv_NguoiDH";
            this.dgv_NguoiDH.RowTemplate.Height = 28;
            this.dgv_NguoiDH.Size = new System.Drawing.Size(671, 471);
            this.dgv_NguoiDH.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.PaleGreen;
            this.panel6.Controls.Add(this.txt_DiaChi);
            this.panel6.Controls.Add(this.txt_TenND);
            this.panel6.Controls.Add(this.txt_SDT);
            this.panel6.Controls.Add(this.lbl_SDT);
            this.panel6.Controls.Add(this.lbl_DiaChi);
            this.panel6.Controls.Add(this.txt_MaND);
            this.panel6.Controls.Add(this.lbl_TenND);
            this.panel6.Controls.Add(this.lbl_MaND);
            this.panel6.Location = new System.Drawing.Point(867, 48);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(6);
            this.panel6.Size = new System.Drawing.Size(370, 411);
            this.panel6.TabIndex = 3;
            // 
            // txt_DiaChi
            // 
            this.txt_DiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DiaChi.Location = new System.Drawing.Point(26, 239);
            this.txt_DiaChi.Name = "txt_DiaChi";
            this.txt_DiaChi.Size = new System.Drawing.Size(325, 30);
            this.txt_DiaChi.TabIndex = 12;
            // 
            // txt_TenND
            // 
            this.txt_TenND.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenND.Location = new System.Drawing.Point(26, 161);
            this.txt_TenND.Name = "txt_TenND";
            this.txt_TenND.Size = new System.Drawing.Size(325, 30);
            this.txt_TenND.TabIndex = 11;
            // 
            // txt_SDT
            // 
            this.txt_SDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SDT.Location = new System.Drawing.Point(26, 320);
            this.txt_SDT.Name = "txt_SDT";
            this.txt_SDT.Size = new System.Drawing.Size(325, 30);
            this.txt_SDT.TabIndex = 7;
            // 
            // lbl_SDT
            // 
            this.lbl_SDT.AutoSize = true;
            this.lbl_SDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SDT.Location = new System.Drawing.Point(23, 290);
            this.lbl_SDT.Name = "lbl_SDT";
            this.lbl_SDT.Size = new System.Drawing.Size(126, 25);
            this.lbl_SDT.TabIndex = 6;
            this.lbl_SDT.Text = "Số điện thoại";
            // 
            // lbl_DiaChi
            // 
            this.lbl_DiaChi.AutoSize = true;
            this.lbl_DiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiaChi.Location = new System.Drawing.Point(23, 209);
            this.lbl_DiaChi.Name = "lbl_DiaChi";
            this.lbl_DiaChi.Size = new System.Drawing.Size(71, 25);
            this.lbl_DiaChi.TabIndex = 4;
            this.lbl_DiaChi.Text = "Địa chỉ";
            // 
            // txt_MaND
            // 
            this.txt_MaND.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaND.Location = new System.Drawing.Point(26, 80);
            this.txt_MaND.Name = "txt_MaND";
            this.txt_MaND.Size = new System.Drawing.Size(325, 30);
            this.txt_MaND.TabIndex = 2;
            // 
            // lbl_TenND
            // 
            this.lbl_TenND.AutoSize = true;
            this.lbl_TenND.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TenND.Location = new System.Drawing.Point(23, 129);
            this.lbl_TenND.Name = "lbl_TenND";
            this.lbl_TenND.Size = new System.Drawing.Size(132, 25);
            this.lbl_TenND.TabIndex = 1;
            this.lbl_TenND.Text = "Tên người đặt";
            // 
            // lbl_MaND
            // 
            this.lbl_MaND.AutoSize = true;
            this.lbl_MaND.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MaND.Location = new System.Drawing.Point(23, 50);
            this.lbl_MaND.Name = "lbl_MaND";
            this.lbl_MaND.Size = new System.Drawing.Size(125, 25);
            this.lbl_MaND.TabIndex = 0;
            this.lbl_MaND.Text = "Mã người đặt";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_HangHoa);
            this.panel2.Controls.Add(this.btn_NguoiDatHang);
            this.panel2.Controls.Add(this.btn_DatChiTiet);
            this.panel2.Controls.Add(this.btn_Dat);
            this.panel2.Location = new System.Drawing.Point(183, 49);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(678, 57);
            this.panel2.TabIndex = 6;
            // 
            // btn_HangHoa
            // 
            this.btn_HangHoa.Location = new System.Drawing.Point(343, 7);
            this.btn_HangHoa.Name = "btn_HangHoa";
            this.btn_HangHoa.Size = new System.Drawing.Size(165, 45);
            this.btn_HangHoa.TabIndex = 2;
            this.btn_HangHoa.Text = "Hàng hóa";
            this.btn_HangHoa.UseVisualStyleBackColor = true;
            this.btn_HangHoa.Click += new System.EventHandler(this.btn_HangHoa_Click);
            // 
            // btn_NguoiDatHang
            // 
            this.btn_NguoiDatHang.Location = new System.Drawing.Point(514, 8);
            this.btn_NguoiDatHang.Name = "btn_NguoiDatHang";
            this.btn_NguoiDatHang.Size = new System.Drawing.Size(161, 45);
            this.btn_NguoiDatHang.TabIndex = 3;
            this.btn_NguoiDatHang.Text = "Người đặt hàng";
            this.btn_NguoiDatHang.UseVisualStyleBackColor = true;
            this.btn_NguoiDatHang.Click += new System.EventHandler(this.btn_NguoiDatHang_Click);
            // 
            // btn_DatChiTiet
            // 
            this.btn_DatChiTiet.Location = new System.Drawing.Point(172, 7);
            this.btn_DatChiTiet.Name = "btn_DatChiTiet";
            this.btn_DatChiTiet.Size = new System.Drawing.Size(165, 45);
            this.btn_DatChiTiet.TabIndex = 1;
            this.btn_DatChiTiet.Text = "Đặt chi tiết";
            this.btn_DatChiTiet.UseVisualStyleBackColor = true;
            this.btn_DatChiTiet.Click += new System.EventHandler(this.btn_DatChiTiet_Click);
            // 
            // btn_Dat
            // 
            this.btn_Dat.Location = new System.Drawing.Point(3, 7);
            this.btn_Dat.Name = "btn_Dat";
            this.btn_Dat.Size = new System.Drawing.Size(163, 45);
            this.btn_Dat.TabIndex = 0;
            this.btn_Dat.Text = "Đặt";
            this.btn_Dat.UseVisualStyleBackColor = true;
            this.btn_Dat.Click += new System.EventHandler(this.btn_Dat_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.pnl_DatMon);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pnl_account);
            this.panel1.Location = new System.Drawing.Point(10, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1244, 596);
            this.panel1.TabIndex = 4;
            // 
            // fNguoiDH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 623);
            this.Controls.Add(this.panel1);
            this.Name = "fNguoiDH";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fNguoiDH";
            this.Load += new System.EventHandler(this.fNguoiDH_Load);
            this.pnl_account.ResumeLayout(false);
            this.pnl_account.PerformLayout();
            this.mns_account.ResumeLayout(false);
            this.mns_account.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.pnl_DatMon.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_NguoiDH)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_account;
        private System.Windows.Forms.MenuStrip mns_account;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_NhaCC;
        private System.Windows.Forms.Button btn_DatHang;
        private System.Windows.Forms.Button btn_TaiKhoan;
        private System.Windows.Forms.Button btn_Menu;
        private System.Windows.Forms.Button btn_BanHang;
        private System.Windows.Forms.Panel pnl_DatMon;
        private System.Windows.Forms.Button btn_Xoa;
        private System.Windows.Forms.Button btn_Them;
        private System.Windows.Forms.Button btn_Sua;
        private System.Windows.Forms.Button btn_TimKiem;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_DiaChi;
        private System.Windows.Forms.TextBox txt_TenND;
        private System.Windows.Forms.TextBox txt_SDT;
        private System.Windows.Forms.Label lbl_SDT;
        private System.Windows.Forms.Label lbl_DiaChi;
        private System.Windows.Forms.TextBox txt_MaND;
        private System.Windows.Forms.Label lbl_TenND;
        private System.Windows.Forms.Label lbl_MaND;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_HangHoa;
        private System.Windows.Forms.Button btn_NguoiDatHang;
        private System.Windows.Forms.Button btn_DatChiTiet;
        private System.Windows.Forms.Button btn_Dat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgv_NguoiDH;

    }
}