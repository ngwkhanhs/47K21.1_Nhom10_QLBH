﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fDatHang : Form
    {
        public fDatHang()
        {
            InitializeComponent();
        }

        private void fDatHang_Load(object sender, EventArgs e)
        {
            dgv_DatHang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_DatHang.DataSource = getData().Tables[0];

            load_MaNCC();
        }

        DataSet getData()
        {

            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM DAT";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);


                connection.Close();
            }

            return data;
        }

        private void load_MaNCC()
        {
            DataSet data = new DataSet();
            
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"select * from NHACUNGCAP";
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbb_MaNhaCC.Items.Add(dr["MaNCC"]);
                }

                connection.Close();
            }
            if (cbb_MaNhaCC.Items.Count>0)
            {
                cbb_MaNhaCC.SelectedIndex = 0;
            }
            
        }

        private void btn_Dat_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatChiTiet_Click(object sender, EventArgs e)
        {
            fDatChiTiet f = new fDatChiTiet();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_HangHoa_Click(object sender, EventArgs e)
        {
            fHangHoa f = new fHangHoa();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NguoiDatHang_Click(object sender, EventArgs e)
        {
            fNguoiDH f = new fNguoiDH();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private bool KiemTra()
        {
            if (txt_MaCT.Text == "" || txt_MaND.Text == "" || txt_TongTien.Text == "" )
            {
                return false;
            }
            return true;
        }


        private void Reset()
        {
            txt_MaCT.Text = "";
            txt_MaCT.Text = "";
            load_MaNCC();
            txt_TongTien.Text = "";
        }

        private void txt_MaCT_TextChanged(object sender, EventArgs e)
        {
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {

            ComboBox NCC = cbb_MaNhaCC;

            if (cbb_MaNhaCC.SelectedItem != null)
            {
                string MaNCC = NCC.SelectedItem.ToString();
                if (KiemTra())
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                    {
                        try
                        {

                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            conn.Open();
                            cmd.CommandText = "ThemDAT";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@MaCT", SqlDbType.NVarChar).Value = txt_MaCT.Text;
                            cmd.Parameters.Add("@MaND", SqlDbType.NVarChar).Value = txt_MaND.Text;
                            cmd.Parameters.Add("@MaNCC", SqlDbType.NVarChar).Value = MaNCC;
                            cmd.Parameters.Add("@NgayCT", SqlDbType.NVarChar).Value = dtp_NgayCT.Value.Date.ToString("yyyy/MM/dd");
                            cmd.Parameters.Add("@Tongtien", SqlDbType.NVarChar).Value = txt_TongTien.Text;
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            fDatHang_Load(sender, e);
                            Reset();
                            MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                }
            }
            
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            ComboBox NCC = cbb_MaNhaCC;

            if (cbb_MaNhaCC.SelectedItem != null)
            {
                string MaNCC = NCC.SelectedItem.ToString();
                if (KiemTra())
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                    {
                        try
                        {

                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            conn.Open();
                            cmd.CommandText = "SuaDAT";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@MaCT", SqlDbType.NVarChar).Value = txt_MaCT.Text;
                            cmd.Parameters.Add("@MaND", SqlDbType.NVarChar).Value = txt_MaND.Text;
                            cmd.Parameters.Add("@MaNCC", SqlDbType.NVarChar).Value = MaNCC;
                            cmd.Parameters.Add("@NgayCT", SqlDbType.NVarChar).Value = dtp_NgayCT.Value.Date.ToString("yyyy/MM/dd");
                            cmd.Parameters.Add("@Tongtien", SqlDbType.NVarChar).Value = txt_TongTien.Text;
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            fDatHang_Load(sender, e);
                            Reset();
                            MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                }
            }
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            ComboBox NCC = cbb_MaNhaCC;

            if (cbb_MaNhaCC.SelectedItem != null)
            {
                string MaNCC = NCC.SelectedItem.ToString();
                if (KiemTra())
                {
                    using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                    {
                        try
                        {

                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            conn.Open();
                            cmd.CommandText = "XoaDAT";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@MaCT", SqlDbType.NVarChar).Value = txt_MaCT.Text;
                            cmd.Parameters.Add("@MaND", SqlDbType.NVarChar).Value = txt_MaND.Text;
                            cmd.Parameters.Add("@MaNCC", SqlDbType.NVarChar).Value = MaNCC;
                            cmd.Parameters.Add("@NgayCT", SqlDbType.NVarChar).Value = dtp_NgayCT.Value.Date.ToString("yyyy/MM/dd");
                            cmd.Parameters.Add("@Tongtien", SqlDbType.NVarChar).Value = txt_TongTien.Text;
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            fDatHang_Load(sender, e);
                            Reset();
                            MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }

                    }
                }
            }
        }
    }
}
