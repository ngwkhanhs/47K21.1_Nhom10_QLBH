﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fDatChiTiet : Form
    {
        public fDatChiTiet()
        {
            InitializeComponent();
        }

        private void fDatChiTiet_Load(object sender, EventArgs e)
        {
            dgv_DatChiTiet.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_DatChiTiet.DataSource = getData().Tables[0];
        }

        DataSet getData()
        {

            DataSet data = new DataSet();

            // string query
            string query = "SELECT * FROM DAT_CHITIET";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(data);


                connection.Close();
            }

            return data;
        }

        private void btn_Dat_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatChiTiet_Click(object sender, EventArgs e)
        {
            fDatChiTiet f = new fDatChiTiet();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_HangHoa_Click(object sender, EventArgs e)
        {
            fHangHoa f = new fHangHoa();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NguoiDatHang_Click(object sender, EventArgs e)
        {
            fNguoiDH f = new fNguoiDH();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        
    }



}
