﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBanHang
{
    public partial class fNhaCC : Form
    {
        public fNhaCC()
        {
            InitializeComponent();
        }

        private void fNhaCC_Load(object sender, EventArgs e)
        {
            dgv_NhaCC.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_NhaCC.DataSource = getData().Tables[0];
        }

        DataSet getData()
        {

            DataSet data = new DataSet();

            // string query
            // var query = "select * from NHACUNGCAP";

            //sql connection
            using (SqlConnection connection = new SqlConnection(ConnectionString.connectionString))
            {
                connection.Open();
                // 
                SqlDataAdapter adapter = new SqlDataAdapter("select * from NHACUNGCAP", connection);
                adapter.Fill(data);

                //
                connection.Close();
            }

            return data;
        }

        private void btn_BanHang_Click(object sender, EventArgs e)
        {
            fBanGhe f = new fBanGhe();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            fMenu f = new fMenu();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_DatHang_Click(object sender, EventArgs e)
        {
            fDatHang f = new fDatHang();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_NhaCC_Click(object sender, EventArgs e)
        {
            fNhaCC f = new fNhaCC();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void btn_TaiKhoan_Click(object sender, EventArgs e)
        {
            fTaiKhoan f = new fTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }


        private bool KiemTra()
        {
            if (txt_MaNhaCC.Text == "" || txt_TenNhaCC.Text == "" || txt_CoSo.Text == "" || txt_SoDienThoai.Text == "" || txt_TenTK.Text == "" || txt_SoTK.Text == "" )
            {
                return false;
            }
            return true;
        }

        private void Reset()
        {
            txt_MaNhaCC.Text = "";
            txt_TenNhaCC.Text = "";
            txt_CoSo.Text = "";
            txt_SoDienThoai.Text = "";
            txt_TenTK.Text = "";
            txt_SoTK.Text = "";
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "ThemNCC";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@MaNCC", SqlDbType.NVarChar).Value = txt_MaNhaCC.Text;
                        cmd.Parameters.Add("@TenNCC", SqlDbType.NVarChar).Value = txt_TenNhaCC.Text;
                        cmd.Parameters.Add("@CS", SqlDbType.NVarChar).Value = txt_CoSo.Text;
                        cmd.Parameters.Add("@SDTNCC", SqlDbType.NVarChar).Value = txt_SoDienThoai.Text;
                        cmd.Parameters.Add("@TenTK", SqlDbType.NVarChar).Value = txt_TenTK.Text;
                        cmd.Parameters.Add("@SoTK", SqlDbType.NVarChar).Value = txt_SoTK.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fNhaCC_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "SuaNCC";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@MaNCC", SqlDbType.NVarChar).Value = txt_MaNhaCC.Text;
                        cmd.Parameters.Add("@TenNCC", SqlDbType.NVarChar).Value = txt_TenNhaCC.Text;
                        cmd.Parameters.Add("@CS", SqlDbType.NVarChar).Value = txt_CoSo.Text;
                        cmd.Parameters.Add("@SDTNCC", SqlDbType.NVarChar).Value = txt_SoDienThoai.Text;
                        cmd.Parameters.Add("@TenTK", SqlDbType.NVarChar).Value = txt_TenTK.Text;
                        cmd.Parameters.Add("@SoTK", SqlDbType.NVarChar).Value = txt_SoTK.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fNhaCC_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã sửa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (KiemTra())
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString.connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand();

                        cmd.CommandText = "ThemNCC";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@MaNCC", SqlDbType.NVarChar).Value = txt_MaNhaCC.Text;
                        cmd.Parameters.Add("@TenNCC", SqlDbType.NVarChar).Value = txt_TenNhaCC.Text;
                        cmd.Parameters.Add("@CS", SqlDbType.NVarChar).Value = txt_CoSo.Text;
                        cmd.Parameters.Add("@SDTNCC", SqlDbType.NVarChar).Value = txt_SoDienThoai.Text;
                        cmd.Parameters.Add("@TenTK", SqlDbType.NVarChar).Value = txt_TenTK.Text;
                        cmd.Parameters.Add("@SoTK", SqlDbType.NVarChar).Value = txt_SoTK.Text;

                        cmd.Connection = conn;
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        fNhaCC_Load(sender, e);
                        Reset();
                        MessageBox.Show("Đã xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }


    }
}
